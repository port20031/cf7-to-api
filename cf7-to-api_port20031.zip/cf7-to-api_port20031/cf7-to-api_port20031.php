<?php
/**
 * Contact form 7 API
 *
 *
 * @link
 * @since             1.0.0
 * @package           cf7-to-api
 *
 * @wordpress-plugin
 * Plugin Name:       Contact form 7 to api
 * Plugin URI:        https://github.com/port20031/cf7-to-api
 * Description:       Connect contact forms 7 to remote API .
 * Version:           1.0.0
 * Author:            port20031
 * Author URI: 		  https://github.com/port20031
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       cf7-to-api
 * Domain Path:       /languages
 */


 add_action('wpcf7_mail_sent','cf7_to_api_port20031');

 function cf7_to_api_port20031( $contact_form){
    $form_id = $contact_form->id();
    //$properties = $contact_form->get_properties();
    $submission = WPCF7_Submission::get_instance();
    $form_posted_data = $submission->get_posted_data();
    $form_title= $contact_form->title;
    
    $form_name = $form_posted_data['your-name'];
    $form_email = $form_posted_data['your-email'];
    $form_tel = $form_posted_data['your-tel'];
    $form_message = $form_posted_data['your-message'];
    
    // add form
    // [hidden utm_source default:get]
    // [hidden utm_medium default:get]
    // [hidden utm_term default:get]
    // [hidden utm_campaign default:get]
    // [hidden utm_content default:get]
    // [hidden gclid default:get]
    
    
    //install Contact Form 7 - Dynamic Text Extension
    // add form 
    // [dynamichidden page-url "CF7_URL"]
    $form_url = $form_posted_data['page-url'];
    
    

    
    


    $url_api = 'https://crm.doctour.store/api/v1/ExternalForm/ContactForm/7396..........4ba'; // json

    $args = array(
        'body' => array(
            'name' => $form_name,
            'email' => $form_email,
            'phone' => $form_tel,
            'msg' => $form_message,
            'url' => $form_url,
            'id' => $form_id,
            'title' => $form_title
        ),

    );
    $args_json = array(
        'headers'     => array('Content-Type' => 'application/json; charset=utf-8'),
        'body'        => json_encode(array(
            'fio' => $form_name,
            'email' => $form_email,
            'phone' => $form_tel,
            'msg' => $form_id .' '.$form_title.':'. $form_message .' <br>url:'.$form_url ,
            'referral_url' => $form_url,
            'id' => $form_id,
            'title' => $form_title
        )),
        'method'      => 'POST',
        'data_format' => 'body'
    );

    wp_remote_post($url_api ,$args_json) ;

 }
